$(document).ready(function(){
    
    // 1. 초기화 함수
    var len = $(".slide").length;
    var cur = 0;
    var sliderW;
    
    function ini(){
        // #slider의 가로,세로 크기 측정.
        // .slide에게 그 크기를 그대로 전달 적용
        // #bus에게도 그 크기를 전달 적용.(가로X슬라이드개수)
        sliderW = $("#slider").width();
        var sliderH = $("#slider").height();
        $(".slide").width(sliderW).height(sliderH);
        $("#bus").width(sliderW * len).css("margin-left",(-1)*sliderW * cur + "px");
    }
    ini();
    $(window).resize(function(){ ini(); });
    
    // 2. 번호관리부 & 구동부 & 페이지액티브조정 함수
    function sliding(dir){
        // 번호관리부
        cur = cur + dir;
        if(cur >= len){
            cur = 0;
        }else if(cur < 0){
            cur = len - 1;
        }
        
        // 구동부
        $("#bus").stop().animate({
            marginLeft: (-1) * sliderW * cur + "px"
        });
    }
    
    // 3. 버튼 실행부
    $(".left").click(function(){ sliding(-1); });
    $(".right").click(function(){ sliding(1); });
    
    // 4. 페이지네이션
    
    // 5. 키보드로 콘트롤하기
    // 문서에서 키가 눌렸을때
        // 만약 눌린 키가 ←(왼쪽키37)라면
            // .left를 누른것이나 마찬가지다
        // 그게아니고 만약 눌린 키가 →(오른쪽키39)라면
            // .right를 누른것이나 마찬가지다
    $(document).keydown(function(e){
        if(e.keyCode == 37){
            $(".left").trigger("click");
        }else if(e.keyCode == 39){
            $(".right").trigger("click");
        };
    });
    
    
});







































